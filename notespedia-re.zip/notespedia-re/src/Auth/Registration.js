import React, { useState } from "react";
import "./signin.css";
import { Link } from "react-router-dom";


const EMAIL_REGEX = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{5,}))$/;

const Registration = () => {
  return (
    <div>Registration</div>
  )
}

export default Registration