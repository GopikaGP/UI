
export const productDetails =  [
    {  
      "id":1,
      "image": "/Images/NewBook1.png",
      "title": "Ikigai : Japanese Art of staying Young.. While grow...",
    //   "picture":require("../Images/Group 44.png"),
      "price1": "$26.00 ",
      "price2": "$42.00"
    },
    {  
      "id":2,
      "image":"/Images/newBook2.png",
      "title": "Ikigai : Japanese Art of staying Young.. While grow...",
    //   "picture":require("../Images/Group 44.png"),
      "price1": "$26.00 ",
      "price2": "$42.00"
    },
    { 
      "id":3,
      "image":"/Images/newbook3.png",
      "title": "Ikigai : Japanese Art of staying Young.. While grow...",
    //   "picture":require("../Images/Group 44.png"),
      "price1": "$26.00 ",
      "price2": "$42.00"
    },
    { 
      "id":4,
      "image":"/Images/newBook4.png",
      "title": "Ikigai : Japanese Art of staying Young.. While grow...",
    //   "picture":require("../Images/Group 44.png"),
      "price1": "$26.00 ",
      "price2": "$42.00"
    },
    {  
      "id":5,
      "image":"/Images/newBook5.png",
      "title":"Ikigai : Japanese Art of staying Young.. While grow...",
    //   "picture":require("../Images/Group 44.png"),
      "price1": "$26.00 ",
      "price2": "$42.00"
    },
    {  
      "id":6,
      "image":"/Images/NewBook1.png",
      "title":"Ikigai : Japanese Art of staying Young.. While grow...",
    //   "picture":require("../Images/Group 44.png"),
      "price1": "$26.00 ",
      "price2": "$42.00"
    },
    {  
      "id":7,
      "image":"/Images/newbook6.jpg",
      "title": "Ikigai : Japanese Art of staying Young.. While grow...",
    //   "picture":require("../Images/Group 44.png"),
      "price1": "$26.00 ",
      "price2": "$42.00"
    },
    // {  
    //   "id":8,
    //   "image":"/Images/BookNotespedia.jpeg",
    //   "title":"Ikigai : Japanese Art of staying Young.. While grow...",
    // //   "picture":require("../Images/Group 44.png"),
    //   "price1": "$26.00 ",
    //   "price2": "$42.00"
    // },
    // {  
    //   "id":9,
    //   "image":"/Images/book5.jpeg",
    //   "title": "Ikigai : Japanese Art of staying Young.. While grow...",
    // //   "picture":require("../Images/Group 44.png"),
    //   "price1": "$26.00 ",
    //   "price2": "$42.00"
    // },
    // {  
    //   "id":10,
    //   "image":"/Images/book6.jpeg",
    //   "title": "Ikigai : Japanese Art of staying Young.. While grow...",
    // //   "picture":require("../Images/Group 44.png"),
    //   "price1": "$26.00 ",
    //   "price2": "$42.00"
    // },
    // {  
    //   "id":11,
    //   "image":"/Images/Book2.jpeg",
    //   "title":"Ikigai : Japanese Art of staying Young.. While grow...",
    // //   "picture":require("../Images/Group 44.png"),
    //   "price1": "$26.00 ",
    //   "price2": "$42.00"
    // },
    // {  
    //   "id":12,
    //   "image":"/Images/Book2.jpeg",
    //   "title": "Ikigai : Japanese Art of staying Young.. While grow...",
    // //   "picture":require("../Images/Group 44.png"),
    //   "price1": "$26.00 ",
    //   "price2": "$42.00"
    // }
  ]
  
  
//   export const shopDetails =  [
//     {
//       image: require("../Images/Watch.png"),
//       title: "Dictum morbi",
//       image1: require("../Images/orangecircle.png"),
//       image2: require("../Images/pinkcircle.png"),
//       image3: require("../Images/bluecircle.png"),
//       price1: "$26.00",
//       price2: "$26.00",
//       content:
//         " Lorem ipsum dolor sit amet, consectetur adipiscing elit. Magnain est adipiscing in phasellus non in justo.",
//       image4: require("../Images/iconss.png"),
//     },
//     {
//       image: require( "../Images/bottle.png"),
//       title: "Sodales sit",
//       image1: require("../Images/orangecircle.png"),
//       image2: require("../Images/pinkcircle.png"),
//       image3: require("../Images/bluecircle.png"),
//       price1: "$26.00",
//       price2: "$26.00",
//       content:
//         " Lorem ipsum dolor sit amet, consectetur adipiscing elit. Magnain est adipiscing in phasellus non in justo.",
//       image4:  require("../Images/iconss.png"),
//     },
//     {
//       image: require("../Images/shoe.png"),
//       title: "Nibh varius",
//       image1: require("../Images/orangecircle.png"),
//       image2:  require("../Images/pinkcircle.png"),
//       image3: require("../Images/bluecircle.png"),
//       price1: "$26.00",
//       price2: "$26.00",
//       content:
//         " Lorem ipsum dolor sit amet, consectetur adipiscing elit. Magnain est adipiscing in phasellus non in justo.",
//       image4:  require("../Images/iconss.png"),
//     },
//     {
//       image: require("../Images/game.png"),
//       title: "Mauris quis",
//       image1:require("../Images/orangecircle.png"),
//       image2:  require("../Images/pinkcircle.png"),
//       image3: require("../Images/bluecircle.png"),
//       price1: "$26.00",
//       price2: "$26.00",
//       content:
//         " Lorem ipsum dolor sit amet, consectetur adipiscing elit. Magnain est adipiscing in phasellus non in justo.",
//       image4:  require("../Images/iconss.png"),
//     },
//     {
//       image: require("../Images/cream.png"),
//       title: "Morbi sagittis",
//       image1: require("../Images/orangecircle.png"),
//       image2:  require("../Images/pinkcircle.png"),
//       image3: require("../Images/bluecircle.png"),
//       price1: "$26.00",
//       price2: "$26.00",
//       content:
//         " Lorem ipsum dolor sit amet, consectetur adipiscing elit. Magnain est adipiscing in phasellus non in justo.",
//       image4:  require("../Images/iconss.png"),
//     },
//     {
//       image: require("../Images/shampo.png"),
//       title: "Ultricies venenatis",
//       image1: require("../Images/orangecircle.png"),
//       image2:  require("../Images/pinkcircle.png"),
//       image3: require("../Images/bluecircle.png"),
//       price1: "$26.00",
//       price2: "$26.00",
//       content:
//         " Lorem ipsum dolor sit amet, consectetur adipiscing elit. Magnain est adipiscing in phasellus non in justo.",
//       image4:  require("../Images/iconss.png"),
//     },
//     {
//       image: require("../Images/greenshoe.png"),
//       title: "Scelerisque dignissim",
//       image1: require("../Images/orangecircle.png"),
//       image2:  require("../Images/pinkcircle.png"),
//       image3: require("../Images/bluecircle.png"),
//       price1: "$26.00",
//       price2: "$26.00",
//       content:
//         " Lorem ipsum dolor sit amet, consectetur adipiscing elit. Magnain est adipiscing in phasellus non in justo.",
//       image4:  require("../Images/iconss.png"),
//     },
//   ]
  
  
  
  