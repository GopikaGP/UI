import React from 'react'
import Layout from '../components/Layout/Layout'

const PagenotFound = () => {
  return (
    <Layout>
        <h1>
        PagenotFound
        </h1>
    </Layout>
  )
}

export default PagenotFound