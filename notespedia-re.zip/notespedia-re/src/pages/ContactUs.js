import React from 'react'
import Layout from '../components/Layout/Layout'

const ContactUs = () => {
  return (
    <Layout>
        <h1>
        ContactUs
        </h1>
        </Layout>
  )
}

export default ContactUs