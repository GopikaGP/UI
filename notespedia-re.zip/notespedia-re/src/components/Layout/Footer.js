import React from 'react'

const Footer = () => {
  return (
    <div className='bg-dark text-light p-3'>
       <h1 className='text-center'>Footer components</h1>
        
        </div>
  )
}

export default Footer