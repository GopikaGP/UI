import React from 'react'

const OurProducts = () => {
  return (
    <div>
      <div className="card w-100 mb-3 mt-4 p-5 card_profile">
        <div className="card-body">
          <h4 className="card=title">Visit our products</h4>
          
      </div>
    </div>
    </div>
   
  )
}

export default OurProducts