import React from "react";
import { Container } from "react-bootstrap";



const Showmore=()=>{

    return(
      <Container>
<div className="seeall">
  <button value='Submit' style={{color:'#05CF64',border:'none', paddingBottom:'8rem',backgroundColor:'#EAF4F1'}}>See all reviews</button>
</div>
</Container>
    )
}
export default Showmore;