import React from 'react';
import Reuse from '../Slider/Reuse.js'

const Readmore = () => {
  return (
    <div>
       <div>
      {/* You can use the ReadMore component and pass a different title */}
      <Reuse title="Read more from Keira Miki" />
    </div>
    </div>
  )
}

export default Readmore