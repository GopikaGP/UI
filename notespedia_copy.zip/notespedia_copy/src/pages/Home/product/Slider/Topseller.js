import React from 'react';
import Reuse from '../Slider/Reuse'

const Topseller = () => {
  return (
    <div>
        <Reuse title="Top Sellers"/>
    </div>
  )
}

export default Topseller