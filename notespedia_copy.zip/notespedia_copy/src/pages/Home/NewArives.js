import React from 'react';
import HomeSlider from './HomeReuse.js';


const NewArives = () => {
  return (
    <div>
      <HomeSlider title="New Arrives"/>
    </div>
  )
}

export default NewArives