import React from 'react';
import HomeSlider from '../Home/HomeReuse.js'

const ImageBank = () => {
  return (
    <div>
      <HomeSlider title="Image Bank"/>
    </div>
  )
}

export default ImageBank