import React from 'react';
import HomeSlider from '../Home/HomeReuse.js'

const Topsellers = () => {
  return (
    <div>
      <HomeSlider title="TopSellers"/>
    </div>
  )
}

export default Topsellers