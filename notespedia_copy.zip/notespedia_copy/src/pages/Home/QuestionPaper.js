import React from 'react';
import HomeSlider from '../Home/HomeReuse.js'
import { Home } from '@mui/icons-material';

const QuestionPaper = () => {
  return (
    <div>
      <HomeSlider title="Question Paper"/>
    </div>
  )
}

export default QuestionPaper