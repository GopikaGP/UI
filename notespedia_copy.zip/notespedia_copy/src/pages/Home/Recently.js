import React from 'react';
import HomeSlider from '../Home/HomeReuse.js'


const Recently = () => {
  return (
    <div>
      <HomeSlider title="Recently added"/>
    </div>
  )
}

export default Recently