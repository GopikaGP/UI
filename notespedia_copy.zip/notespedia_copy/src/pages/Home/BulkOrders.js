import React from 'react';
import HomeSlider from '../Home/HomeReuse.js'

const BulkOrders = () => {
  return (
    <div>
      <HomeSlider title="BulkOrders"/>
    </div>
  )
}

export default BulkOrders