import React from 'react'

const Paymentcart = () => {
  return (
    <div>Paymentcart</div>
  )
}

export default Paymentcart