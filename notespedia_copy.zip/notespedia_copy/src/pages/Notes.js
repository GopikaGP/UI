import React from 'react'
import Layout from '../components/Layout/Layout'

const Notes = () => {
  return (
    <Layout>
        <h1>
        Notes
        </h1>
    </Layout>
  )
}

export default Notes