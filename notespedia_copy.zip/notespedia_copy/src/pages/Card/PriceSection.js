import React from 'react'

const PriceSection = () => {
  return (
    <div>PriceSection</div>
  )
}

export default PriceSection